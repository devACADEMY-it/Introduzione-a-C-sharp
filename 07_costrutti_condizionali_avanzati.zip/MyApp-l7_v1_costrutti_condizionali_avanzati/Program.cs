﻿// costanti
// Solo i tipi predefiniti C# System.Object (escluso) possono essere dichiarati come const
// NOTE: https://docs.microsoft.com/it-it/dotnet/csharp/language-reference/builtin-types/built-in-types
const double PI = 3.14;
const string API_URL = "https://localhost/api/";

var stagioneCorrente = Stagione.Autunno; // definito nel file MyEnums.cs F12 per navigare
Console.WriteLine(stagioneCorrente);

// conversione
int stagioneCorrenteInt = (int)stagioneCorrente;
Console.WriteLine(stagioneCorrenteInt);

var inverno = (Stagione)3;
Console.WriteLine(inverno);

var responseStatus = HttpStatusCode.ErroreDelServer;
Console.WriteLine((ushort)responseStatus);

// if elseif else
if (stagioneCorrente == Stagione.Primavera)
{
    Console.WriteLine("In primavera sbocciano i fiori.");
}
else if (stagioneCorrente == Stagione.Estate)
{
    Console.WriteLine("In estate andiamo al mare.");
}
else if (stagioneCorrente == Stagione.Autunno)
{
    Console.WriteLine("In autunno piove.");
}
else
{
    Console.WriteLine("In invero nevica.");
}

var meseCorrente = Mese.Gennaio;

switch (meseCorrente)
{
    case Mese.Gennaio:
        Console.WriteLine($"Gennaio è il mese numero {(int)meseCorrente} dell'anno.");
        break;
    case Mese.Febbraio:
        Console.WriteLine($"Febbraio è il mese numero {(int)meseCorrente} dell'anno.");
        break;
    case Mese.Marzo:
        Console.WriteLine($"Marzo è il mese numero {(int)meseCorrente} dell'anno.");
        break;
    case Mese.Aprile:
        Console.WriteLine($"Aprile è il mese numero {(int)meseCorrente} dell'anno.");
        break;
    default:
        Console.WriteLine("Questo mese è parte degli ultimi 2 quadrimestri.");
        break;
}

switch (meseCorrente)
{
    case Mese.Novembre:
    case Mese.Aprile:
    case Mese.Giugno:
    case Mese.Settembre:
        Console.WriteLine($"{meseCorrente} ha 30 giorni.");
        break;
    case Mese.Febbraio:
        Console.WriteLine($"{meseCorrente} ha 28 giorni.");
        break;
    default:
        Console.WriteLine($"Tutti gli altri ne hanno 31, compreso {meseCorrente}.");
        break;
}
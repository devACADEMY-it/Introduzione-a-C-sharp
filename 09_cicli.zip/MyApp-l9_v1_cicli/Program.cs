﻿// istruzioni di iterazione: cicli
// data una lista, la percorriamo (cicliamo) dal primo all'ultimo elemento
// facendo qualcosa ad ogni elemento

// ciclo for
// esegue il corpo mentre un'espressione booleana specificata restituisce true
for (int i = 0; i < 3; i++)
{
    Console.WriteLine(i);
}

string[] strArray = { "undici", "due", "tre", "dieci" };
for (int i = 0; i < strArray.Length; i++)
{
    Console.WriteLine(strArray[i]);
}

int[] intArray = { 1, 2, 3, 4 };
for (int i = 0; i < strArray.Length; i++)
{
    if (intArray[i] % 2 == 0)
    {
        Console.WriteLine($"Il numero {intArray[i]} è pari");
    }
    else
    {
        Console.WriteLine($"Il numero {intArray[i]} è dispari");
    }

}

// ciclo foreach
// enumera gli elementi di una raccolta ed esegue il relativo corpo per ogni elemento della raccolta
var fibNumbers = new List<int> { 0, 1, 1, 2, 3, 5, 8, 13 };
foreach (var element in fibNumbers)
{
    if (element % 2 == 0)
    {
        Console.WriteLine($"Il numero {element} è pari");
    }
    else
    {
        Console.WriteLine($"Il numero {element} è dispari");
    }
}

foreach (var element in strArray)
{
    Console.WriteLine(element.ToUpper());
}


// ciclo do
// esegue in modo condizionale il corpo UNA o più volte
// esegue prima il codice e poi controlla la condizione
int contatore = 0;
do
{
    Console.WriteLine($"Ciclo do: {contatore}");
    contatore++;
} while (contatore < 5);

// ciclo while
// Il ciclo while testa la condizione prima di eseguire il codice
// esegue in modo condizionale il corpo ZERO o più volte.
contatore = 0;
while (contatore < 5)
{
    Console.WriteLine($"Ciclo while: {contatore}");
    contatore++;
}

// interruzione cicli
// In qualsiasi punto all'interno del corpo di un'istruzione di iterazione
// è possibile uscire dal ciclo usando "break"
// o passare all'iterazione successiva nel con "continue"
contatore = 0;
while (contatore < 10)
{
    if (contatore == 1 || contatore == 5)
    {
        contatore++;
        continue; // non logga 1 e 5
    }

    if (contatore == 8)
    {
        break; // esce a 8, quindi logga fino a 7
    }

    Console.WriteLine($"Ciclo while continue: {contatore}");
    contatore++;
}

foreach (var element in strArray)
{
    if (element == "tre")
    {
        break;
    }

    Console.WriteLine(element.ToUpper());
}
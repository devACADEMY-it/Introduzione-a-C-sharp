﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
// Console.WriteLine("Ciao a tutti.");
Console.WriteLine("Oggi è il " + DateTime.Now.ToString());

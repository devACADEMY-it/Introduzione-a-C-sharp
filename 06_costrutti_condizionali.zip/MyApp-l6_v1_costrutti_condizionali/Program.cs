﻿/*
I costrutti condizionali (o istruzioni di selezione)
sono delle espressioni che consentono di
eseguire o meno una porzione di codice
in base ad una condizione
*/

int etaUtente = 19;

// costrutto if
if (etaUtente >= 18)
{
    // se vero
    Console.WriteLine($"L'utente ha {etaUtente} anni e quindi è maggiorenne.");
}


// costrutto if else
if (etaUtente >= 18)
{
    // se vero
    Console.WriteLine($"L'utente ha {etaUtente} anni e quindi è maggiorenne.");
}
else
{
    // se falso
    Console.WriteLine($"L'utente ha {etaUtente} anni e quindi è minorenne.");
}

bool abilitatoAllaProfessione = true;

if (etaUtente >= 18 && abilitatoAllaProfessione) // == true
{
    // se vero
    Console.WriteLine($"L'utente può essere assunto.");
}
else
{
    // se falso
    Console.WriteLine($"L'utente non può essere assunto.");
}

// if annidati
if (etaUtente >= 18)
{
    if (abilitatoAllaProfessione)
    {
        Console.WriteLine($"L'utente è maggiorenne e abilitato, può essere assunto");
    }
    else
    {
        Console.WriteLine($"L'utente è maggiorenne ma non abilitato, non può essere assunto");
    }
}
else
{
    Console.WriteLine($"L'utente è minorenne e quindi non può essere assunto");
}

// operatore ternario
string etichetta = string.Empty;
if (etaUtente >= 18)
{
    etichetta = "maggiorenne";
}
else
{
    etichetta = "minorenne";
}

etichetta = etaUtente >= 18 ? "maggiorenne" : "minorenne";

etichetta = etaUtente >= 18 && abilitatoAllaProfessione ? "assunto" : "non assunto";


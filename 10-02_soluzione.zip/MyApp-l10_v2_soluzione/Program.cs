﻿// date 3 variabili di tipo DateTime
// 1. creare una List che contenga le 3 date
// 2. ciclare sulla lista di date
// 3. per ogni data, in base al mese e al giorno, capire in quale stagione ci troviamo
// 4. loggare i 3 risultati in Console
// 5. utilizzate gli enums (Stagione e Mese) nel file MyEnums.cs

// le 3 variabili data definite come data odierna, data mese precedente e data mese successivo
var oggi = DateTime.Now;
// var oggi = new DateTime(2022, 3, 22); // per testare altre date
var meseScorso = oggi.AddMonths(-1);
var meseSuccessivo = oggi.AddMonths(1);

// esempio per ricavare giorno e mese da una variabile data
// var mese = oggi.Month;
// var giorno = oggi.Day;

List<DateTime> date = new List<DateTime> { oggi };
date.Add(meseScorso);
date.Add(meseSuccessivo);

foreach (var data in date)
{
    var mese = data.Month;
    var giorno = data.Day;
    Stagione? stagione = null;

    switch ((Mese)mese)
    {
        case Mese.Gennaio:
        case Mese.Febbraio:
            stagione = Stagione.Inverno;
            break;
        case Mese.Aprile:
        case Mese.Maggio:
            stagione = Stagione.Primavera;
            break;
        case Mese.Luglio:
        case Mese.Agosto:
            stagione = Stagione.Estate;
            break;
        case Mese.Ottobre:
        case Mese.Novembre:
            stagione = Stagione.Autunno;
            break;
        case Mese.Dicembre:
            stagione = giorno >= 23 ? Stagione.Inverno : Stagione.Autunno;
            break;
        case Mese.Marzo:
            stagione = giorno >= 21 ? Stagione.Primavera : Stagione.Inverno;
            break;
        case Mese.Giugno:
            stagione = giorno >= 22 ? Stagione.Estate : Stagione.Primavera;
            break;
        case Mese.Settembre:
            stagione = giorno >= 23 ? Stagione.Autunno : Stagione.Estate;
            break;
    }

    if (stagione.HasValue)
    {
        Console.WriteLine($"Il giorno {data.ToShortDateString()} è {stagione.Value.ToString().ToUpper()}.");
    }
    else
    {
        Console.WriteLine($"Il giorno {data.ToShortDateString()} non sono riuscito a capire in che stagione sia.");
    }
}
Console.ReadLine();
// dotnet publish -c Release -o build
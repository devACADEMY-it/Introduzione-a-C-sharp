﻿// dichiarazione variabili
int valoreiIntero;

// assegnazione valore
valoreiIntero = 5;

// dichiarazione variabili multiple
int val1, val2, val3;

// dichiarazione e assegnazione
int val4 = 67;
var val5 = "stringa";

// tipo string
string valStringa1, valStringa2;
valStringa1 = "stringa 1";
valStringa2 = "stringa 2";

// tipo bool
bool valBool = true;
bool valBoo2 = false;

// tipo decimal
double numeroConVirgola = 4.8;

var lunghezzaString = valStringa1.Length;

// tipo DateTime
DateTime dataOra = DateTime.Now;
dataOra.AddHours(1);


int five = 5;

// casting
var fiveDouble = (double)five;

// casting implicito (no perdita di dati)
double fiveDouble2 = five;

// casting esplicito
double dblFour = 4.7;
int intFour = (int)dblFour;//4

// casting non consentito
string myString = "Frase di esempio";
// byte myByte = (byte)myString; // non compila

// conversione con arrotondamento
int fourInt = Convert.ToInt32(dblFour); //5

// parsing
string strTwo = "2";
int twoInteger = int.Parse(strTwo);

DateTime oggi = DateTime.Parse("12/12/2021");

// operatore is
var mioValore = 6.5M; // M significa tipo decimal
if (mioValore is decimal) {

}

// operatore as
string testString = "Test";
object objString = (object)testString;
var test2 = objString as string;

// tipi nullable
bool? flag = null;

double? pi = 3.14;
char? letter = 'a';

int m2 = 10;
int? m = m2;

// hasvalue
int? b = 10;
if (b.HasValue) // true
{
    
}

int? c = 7;
if (c != null) // true
{
    
}

// operatore ??
int? a = 28;
int f = a ?? -1; // 28

int? h = null;
int d = h ?? -1; // -1

int? n = null;

//int m1 = n;    // non compila
int n2 = (int)n; // compila ma va in errore se n è null

Console.WriteLine("Hello, World!");


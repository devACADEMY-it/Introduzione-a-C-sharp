﻿// assegnazione e aritmetci
int x = 10;

int? nn = null;
int num = nn ?? 0;

int j = 9;
int k = 3;
int risultato = 0;

risultato = j + k;
risultato = j - k;
risultato = j * k;
risultato = j / k;
risultato = j % k; // 0

risultato++; // incremento di 1
risultato--; // decremento di 1

risultato += 3; // risultato = risultato + 3;
// risultato -= 3; // risultato = risultato - 3;
risultato *= 3; // risultato = risultato * 3;
risultato /= 3; // risultato = risultato / 3;

Console.WriteLine(risultato);

// di confronto e logici
bool blnRisultato = true;
blnRisultato = j == k; // false
blnRisultato = j != k; // true
blnRisultato = j >= k; // true
blnRisultato = j <= k; // false
blnRisultato = j > k; // true
blnRisultato = j < k; // false

// ! && ||
bool bello = true;
bool buono = false;

blnRisultato = bello && buono; // false
Console.WriteLine(blnRisultato);

blnRisultato = bello || buono; // true
Console.WriteLine(blnRisultato);

blnRisultato = !bello; // false
Console.WriteLine(blnRisultato);
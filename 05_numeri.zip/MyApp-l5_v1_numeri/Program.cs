﻿// tipi di dato

// interi
byte byte_byte = 4;
Byte byteType = 4;

int intero_int = 5;
Int32 intero32 = 5;

short intero16_short = 5;
Int16 intero16 = 5;

long intero64_long = 5;
Int64 intero64 = 5;

ushort unsignedShort = 3;
uint unsignedInt = 3;
ulong unsignedLong = 3;

// decimali
float single_float = 1.5f;
Single single = 1.5f;

double dbl_double = 1.5d; // 1.5 d (default)
Double dbl = 1.5d;

decimal dcml_ddecimal = 1.5m;
Decimal dcml = 1.5m;

// conversioni tra numeri
// https://docs.microsoft.com/it-it/dotnet/csharp/language-reference/builtin-types/numeric-conversions

// implicita (no perdita di dati)
int fromInt = 56;
double toDouble = fromInt;

// esplicita (possobile perdita di dati)
short toShort = (short)fromInt;

//////////////////////////////////////////////

// precisione e limiti
// int
int a = 7;
int b = 4;
int c = 3;
int d = (a + b) / c;
int e = (a + b) % c;
Console.WriteLine($"Quoziente: {d}");
Console.WriteLine($"Resto: {e}");

int max = int.MaxValue;
int min = int.MinValue;
Console.WriteLine($"Range di integers {min} / {max}");

// overflow, "ritorno a capo"
int oltre = max + 3;
Console.WriteLine($"Esempio di overflow: {oltre}");

// double, virgola mobile
double da = 5;
double db = 4;
double dc = 2;
double dd = (da + db) / dc;
Console.WriteLine(dd);

double da2 = 19;
double db2 = 23;
double dc2 = 8;
double dd2 = (da2 + db2) / dc2;
Console.WriteLine(dd2);

double dmax = double.MaxValue;
double dmin = double.MinValue;
Console.WriteLine($"Range di double {dmin} / {dmax}");

double third = 1.0 / 3.0;
Console.WriteLine(third);

// decimal (intervallo più piccolo rispetto a double ma maggire precisione)
// include più cifrea  destra del decimale
decimal mmin = decimal.MinValue;
decimal mmax = decimal.MaxValue;
Console.WriteLine($"Range di decimal {mmin} / {mmax}");

double dA = 1.0;
double dB = 3.0;
Console.WriteLine(dA / dB);

decimal mC = 1.0M;
decimal mD = 3.0M;
Console.WriteLine(mC / mD);

// area del cerchio
double r = 2.5;
Console.WriteLine(r * r * Math.PI);
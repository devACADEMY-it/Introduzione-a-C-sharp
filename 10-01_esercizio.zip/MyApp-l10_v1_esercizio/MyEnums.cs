// enums
// Un tipo di enumerazione (o tipo enum) è un tipo valore definito da un set di costanti denominate
// del tipo numerico integrale sottostante.
enum Stagione
{
    Primavera,
    Estate,
    Autunno,
    Inverno
}

enum HttpStatusCode : ushort
{
    Ok = 200,
    Spostato = 301,
    NonAutorizzato = 401,
    ErroreDelServer = 500
}

enum Mese
{
    Gennaio = 1,
    Febbraio = 2,
    Marzo = 3,
    Aprile = 4,
    Maggio = 5,
    Giugno = 6,
    Luglio = 7,
    Agosto = 8,
    Settembre = 9,
    Ottobre = 10,
    Novembre = 11,
    Dicembre = 12
}
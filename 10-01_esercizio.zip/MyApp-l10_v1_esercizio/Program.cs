﻿// date 3 variabili di tipo DateTime
// 1. creare una List che contenga le 3 date
// 2. ciclare sulla lista di date
// 3. per ogni data, in base al mese e al giorno, capire in quale stagione ci troviamo
// 4. loggare i 3 risultati in Console
// 5. utilizzate gli enums (Stagione e Mese) nel file MyEnums.cs

// le 3 variabili data definite come data odierna, data mese precedente e data mese successivo
var oggi = DateTime.Now;
// var oggi = new DateTime(2022, 3, 22); // per testare altre date
var meseScorso = oggi.AddMonths(-1);
var meseSuccessivo = oggi.AddMonths(1);

// esempio per ricavare giorno e mese da una variabile data
// var mese = oggi.Month;
// var giorno = oggi.Day;
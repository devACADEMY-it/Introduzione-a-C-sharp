﻿// concatenazione
string amico = "Gigi";

Console.WriteLine("Ciao " + amico + "!");

// interpolazione
Console.WriteLine($"Ciao {amico}!");

string altroAmico = "Mario";
Console.WriteLine($"I miei amici sono {amico} e {altroAmico}.");

// proprietà delle stringhe
Console.WriteLine($"Il nome {amico} ha {amico.Length} lettere.");
Console.WriteLine($"Il nome {altroAmico} ha {altroAmico.Length} lettere.");

// conversione
char a = 'a';
int eta = 31;
double altezza = 1.56;

Console.WriteLine($"La mia amica {amico}{a} ha {eta} anni ed è alta {altezza} metri.");

// operazioni sulle stringhe

//trim
string saluti = "      Ciao Mondo!       ";
Console.WriteLine($"[{saluti}]");

string trimmedSaluti = saluti.TrimStart();
Console.WriteLine($"[{trimmedSaluti}]");

trimmedSaluti = saluti.TrimEnd();
Console.WriteLine($"[{trimmedSaluti}]");

trimmedSaluti = saluti.Trim();
Console.WriteLine($"[{trimmedSaluti}]");

// replace
string ciao = "Ciao Mondo!";
Console.WriteLine(ciao);
ciao = ciao.Replace("Ciao", "Buongiorno", false, null);
Console.WriteLine(ciao);
ciao = ciao.Replace("ciao", "Buongiorno", false, null);
Console.WriteLine(ciao);
ciao = ciao.Replace("ciao", "Buongiorno", true, null);
Console.WriteLine(ciao);

// upper, lower
Console.WriteLine(ciao.ToUpper());
Console.WriteLine(ciao.ToLower());

// ricerca
string songLyrics = "Tu dici addio, io dico arrivederci";
Console.WriteLine(System.Globalization.CultureInfo.CurrentCulture);
Console.WriteLine(songLyrics.Contains("addio"));
Console.WriteLine(songLyrics.Contains("saluti"));

Console.WriteLine(songLyrics.StartsWith("Tu"));
Console.WriteLine(songLyrics.StartsWith("tu", false, null));
Console.WriteLine(songLyrics.StartsWith("tu", true, null));
Console.WriteLine(songLyrics.EndsWith("Tu"));

string albero = "albERo";
Console.WriteLine(albero.Substring(0, 1)); // a
Console.WriteLine(albero.Substring(2, 3)); // bER
Console.WriteLine($"{albero.Substring(0, 1).ToUpper()}{albero.Substring(1).ToLower()}");
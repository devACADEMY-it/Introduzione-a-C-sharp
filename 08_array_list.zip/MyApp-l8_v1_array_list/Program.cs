﻿/*
//
Immagazzina un elenco di valori dello stesso tipo
Una matrice viene dichiarata specificando il tipo degli elementi.
Se si desidera che la matrice archivi elementi di qualsiasi tipo, è possibile object specificarne il tipo.
*/

// array
// dichiarazione specificando la dimensione.
int[] array1 = new int[5];

// dichiarazione specificando gli elementi.
int[] array2 = new int[] { 1, 3, 5, 7, 9 };
int[] array3 = { 1, 2, 3, 4, 5, 6 }; // sintassi alternativa

int[] array4;
array4 = new int[] { 1, 3, 5, 7, 9 };   // OK
//array4 = {1, 3, 5, 7, 9};   // Errore

Mese[] mesiCaldi = { Mese.Giugno, Mese.Luglio, Mese.Agosto };

string[] giorni = { "Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab" };

Console.WriteLine(giorni[0]);
Console.WriteLine(giorni[1]);
Console.WriteLine(giorni[2]);
Console.WriteLine(giorni[3]);
Console.WriteLine(giorni[4]);
Console.WriteLine(giorni[5]);
Console.WriteLine(giorni[6]);

Console.WriteLine(mesiCaldi[1]);

// generics
// introducono il concetto di parametro di tipo
// cioè passare un tipo di dato come parametro
// l'utilizzo più comune è nelle liste
List<int> listaDiInteri = new List<int>() { 1, 2, 3 };
Console.WriteLine(listaDiInteri.Count);

List<string> listaDiStringhe = new List<string> { "uno", "due" };
Console.WriteLine(listaDiStringhe.Count);

var oggi = DateTime.Now;
List<DateTime> listaDiDate = new List<DateTime> { oggi };
Console.WriteLine(listaDiDate.Count);

// list
// rappresenta un elenco di oggetti fortemente tipizzato accessibile per indice
// fornisce metodi per la ricerca, l'ordinamento e la modifica degli elenchi.
// alternativa ad array più "comoda" da usare
List<int> numeriPrimi = new List<int>() { 2, 3, 5 };
Console.WriteLine($"La lista contiene {numeriPrimi.Count} elementi.");

numeriPrimi.Add(7);
Console.WriteLine($"La lista contiene {numeriPrimi.Count} elementi.");

int[] undiciETredici = { 11, 13 };
numeriPrimi.AddRange(undiciETredici);
Console.WriteLine($"La lista contiene {numeriPrimi.Count} elementi.");

int[] finoATrentasette = { 19, 23, 29, 31, 37 };
numeriPrimi.AddRange(finoATrentasette);

int index = numeriPrimi.IndexOf(11);
Console.WriteLine($"La lista contiene {numeriPrimi[index]} all'indice {index}.");
Console.WriteLine($"Elementi: {string.Join(',', numeriPrimi)}");

numeriPrimi.Insert(6, 17);
Console.WriteLine($"Elementi: {string.Join(',', numeriPrimi)}");

numeriPrimi.Remove(31);
Console.WriteLine($"Elementi: {string.Join(',', numeriPrimi)}");

numeriPrimi.Add(31);
Console.WriteLine($"Elementi: {string.Join(',', numeriPrimi)}");

numeriPrimi.Sort();
Console.WriteLine($"Elementi: {string.Join(',', numeriPrimi)}");

numeriPrimi.Reverse();
Console.WriteLine($"Elementi: {string.Join(',', numeriPrimi)}");
